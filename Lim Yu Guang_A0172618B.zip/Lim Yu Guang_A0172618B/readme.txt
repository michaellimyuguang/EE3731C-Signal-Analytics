Instructions
1. Change file location in MATLAB to this specific file location
2. Select sem1_2019_encrypt.mat under the Current Folder tab to load the information into the Workspace.
3. Run the commands as stated in EE3731C_encrypt to compute the desired output.