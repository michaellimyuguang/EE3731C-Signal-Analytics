function WaveletMotivation

Fs = 50;
T = 1/Fs;
L = 200;
t = (0:L-1)*T;
f1 = 0.5;
f2 = 5;
ep = find(t == 2);

% Generate x1 time course
x1 = 0.5*sin(2*pi*f1*t) + 0.5*sin(2*pi*f2*t);

% save figure
h = figure; pos = get(h, 'Position'); pos(3) = 1200; pos(4) = 300;
set(h, 'Position', pos); 
plot(t, x1, 'LineWidth', 2);
set(gca, 'FontSize', 36);
set(gcf, 'PaperPositionMode', 'auto');
saveas(gcf, ['figures/x1_timecourse.eps'], 'epsc');

% x1 FFT
NFFT = 2^nextpow2(length(x1));
X1 = fft(x1, NFFT)/length(x1);
f = Fs/2*linspace(0, 1, NFFT/2 + 1);

% save figure
h = figure; pos = get(h, 'Position'); pos(3) = 1200; pos(4) = 300;
set(h, 'Position', pos); 
plot(f, 2*abs(X1(1:NFFT/2+1)), 'LineWidth', 2);
set(gca, 'FontSize', 36);
a = axis; a(1:2) = [0 20]; axis(a);
set(gcf, 'PaperPositionMode', 'auto');
saveas(gcf, ['figures/x1_spectrum.eps'], 'epsc');

% Generate x2 timecourse
x2 = [sin(2*pi*f1*t(1:ep)) sin(2*pi*f2*t(ep+1:end))];

% save figure
h = figure; pos = get(h, 'Position'); pos(3) = 1200; pos(4) = 300;
set(h, 'Position', pos); 
plot(t, x2, 'LineWidth', 2);
set(gca, 'FontSize', 36);
set(gcf, 'PaperPositionMode', 'auto');
saveas(gcf, ['figures/x2_timecourse.eps'], 'epsc');

pos(3) = 600; pos(4) = 300;
set(h, 'Position', pos); 
saveas(gcf, ['figures/x2_timecourse_sq.eps'], 'epsc');

% x2 FFT
NFFT = 2^nextpow2(length(x2));
X2 = fft(x2, NFFT)/length(x2);
f = Fs/2*linspace(0, 1, NFFT/2 + 1);

% save figure
h = figure; pos = get(h, 'Position'); pos(3) = 1200; pos(4) = 300;
set(h, 'Position', pos); 
plot(f, 2*abs(X2(1:NFFT/2+1)), 'LineWidth', 2);
set(gca, 'FontSize', 36);
a = axis; a(1:2) = [0 20]; axis(a);
set(gcf, 'PaperPositionMode', 'auto');
saveas(gcf, ['figures/x2_spectrum.eps'], 'epsc');

% STFT
spec = spectrogram(x2, 64);
h = figure; pos = get(h, 'Position'); pos(3) = 1200; pos(4) = 300;
set(h, 'Position', pos); 
imagesc(abs(spec(end:-1:1, :)))
axis off;
set(gcf, 'PaperPositionMode', 'auto');
saveas(gcf, ['figures/x2_STFT64.eps'], 'epsc');

spec = spectrogram(x2, 16);
h = figure; pos = get(h, 'Position'); pos(3) = 1200; pos(4) = 300;
set(h, 'Position', pos); 
imagesc(abs(spec(end:-1:1, :)))
axis off;
set(gcf, 'PaperPositionMode', 'auto');
saveas(gcf, ['figures/x2_STFT16.eps'], 'epsc');


