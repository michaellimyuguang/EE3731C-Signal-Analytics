function ShiftInvariant

[Lo_D,Hi_D] = wfilters('db8');

% create signal exactly matching Hi_D
x = [zeros(1, 24) Hi_D(end:-1:1) zeros(1, 24)];

% Normal 3 level dwt
[CD1, CD2, CD3, CA3] = dwt_3levels(x, Lo_D, Hi_D);

% shift x and perform transform again
x_circ = circshift(x', 1)';
[CD1c, CD2c, CD3c, CA3c] = dwt_3levels(x_circ, Lo_D, Hi_D);

% Plot wavelet coefficients
h = figure; pos = get(h, 'Position'); pos([3 4]) = [1200 300];
set(gcf, 'Position', pos); 
fontsize = 24;

subplot(2, 4, 1); stem(x); set(gca, 'FontSize', fontsize); a = [1 length(x) -1 1]; axis(a);
subplot(2, 4, 1+4); stem(x_circ); set(gca, 'FontSize', fontsize); a = [1 length(x) -1 1]; axis(a);

subplot(2, 4, 2); stem(CD1); set(gca, 'FontSize', fontsize); a = [1 length(CD1) -1.5 1.5]; axis(a);
subplot(2, 4, 2+4); stem(CD1c); set(gca, 'FontSize', fontsize); a = [1 length(CD1) -1.5 1.5]; axis(a);

subplot(2, 4, 3); stem(CD2); set(gca, 'FontSize', fontsize); a = [1 length(CD2) -0.5 0.5]; axis(a);
subplot(2, 4, 3+4); stem(CD2c); set(gca, 'FontSize', fontsize); a = [1 length(CD2) -0.5 0.5]; axis(a);

subplot(2, 4, 4); stem(CD3); set(gca, 'FontSize', fontsize); a = [1 length(CD3) -0.02 0.02]; axis(a);
subplot(2, 4, 4+4); stem(CD3c); set(gca, 'FontSize', fontsize); a = [1 length(CD3) -0.02 0.02]; axis(a);

set(gcf, 'PaperPositionMode', 'auto'); set(gca, 'FontSize', 24); saveas(gcf, ['figures/translational_variance.eps'], 'epsc');


function [CD1, CD2, CD3, CA3] = dwt_3levels(x, Lo_D, Hi_D)

[CA, CD1] = dwt(x, Lo_D, Hi_D);
[CA, CD2] = dwt(CA, Lo_D, Hi_D);
[CA3, CD3] = dwt(CA, Lo_D, Hi_D);