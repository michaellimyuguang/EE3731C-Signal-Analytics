function Haar2D

% Haar
Lo_D = [sqrt(2)/2 sqrt(2)/2];
Hi_D = [-sqrt(2)/2 sqrt(2)/2];
Lo_R = [sqrt(2)/2 sqrt(2)/2];
Hi_R = [sqrt(2)/2 -sqrt(2)/2];

% load image 
load woman;
X = X/max(X(:));

% plot image
figure; imshow(X, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;  
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman.eps'], 'epsc');

% DWT on rows
for i = 1:size(X, 1)
    [L(i, :), H(i, :)] = dwt(X(i, :), Lo_D, Hi_D);
end

% Plot DWT on rows
figure; imshow(L, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_L.eps'], 'epsc');
figure; imshow(H, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_H.eps'], 'epsc');

% Dwt on columns
for i = 1:size(L, 2)
    [LL(:, i), LH(:, i)] = dwt(L(:, i), Lo_D, Hi_D);
    [HL(:, i), HH(:, i)] = dwt(H(:, i), Lo_D, Hi_D);
end

% Plot 1st level Haar
figure; imshow(LL, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_LL.eps'], 'epsc');
figure; imshow(LH, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_LH.eps'], 'epsc');
figure; imshow(HL, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_HL.eps'], 'epsc');
figure; imshow(HH, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_HH.eps'], 'epsc');

% Run Haar for 3 levels.
coeffs1 = my_dwt2(X, Lo_D, Hi_D);

coeffs2 = coeffs1; 
coeffs2(1:end/2, 1:end/2) = my_dwt2(coeffs1(1:end/2, 1:end/2), Lo_D, Hi_D);

coeffs3 = coeffs2; 
coeffs3(1:end/4, 1:end/4) = my_dwt2(coeffs2(1:end/4, 1:end/4), Lo_D, Hi_D);

% Plot Haar at different levels
figure; imshow(coeffs1, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_haar1.eps'], 'epsc');
figure; imshow(coeffs2, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_haar2.eps'], 'epsc');
figure; imshow(coeffs3, []); set(gcf, 'PaperPositionMode', 'auto'); h = colorbar;   
YTick = get(h, 'YTick'); set(h, 'YTick', YTick([1 end])); set(gca, 'FontSize', 24); saveas(gcf, ['figures/woman_haar3.eps'], 'epsc');



function coeffs = my_dwt2(X, Lo_D, Hi_D)

[CA, CH, CV, CD] = dwt2(X, Lo_D, Hi_D);
coeffs = [CA CH; CV CD];