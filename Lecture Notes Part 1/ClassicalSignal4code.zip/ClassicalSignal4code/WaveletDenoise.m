function WaveletDenoise

% This assumes that you have downloaded wavelab from http://statweb.stanford.edu/~wavelab/
% and placed the toolbox in the following place (like I have). If it's in
% a different location, just change the path accordingly.
addpath('/Applications/MATLAB_R2012a.app/toolbox/Wavelab850');
WavePath;

DenoiseAux('lena');
DenoiseAux('mri');
DenoiseAux('woman');


function DenoiseAux(imname)

rng(1000);

% load image
load(imname);
X = X/max(X(:));

% draw image
figure; imshow(X, []); set(gcf, 'PaperPositionMode', 'auto'); set(gca, 'FontSize', 24); saveas(gcf, ['figures/' imname '.eps'], 'epsc');

% add noise
Xn = X + randn(size(X))*0.1;
n_snr = psnr(Xn, X)
figure; imshow(Xn, []); set(gcf, 'PaperPositionMode', 'auto'); set(gca, 'FontSize', 24); saveas(gcf, ['figures/' imname '_noise.eps'], 'epsc');

% Plot noisy wavelet coefficients
qmf = MakeONFilter('Symmlet',4);
Xn_coeffs = FWT2_PO(Xn, 3, qmf);
figure; imshow(Xn_coeffs, []); set(gcf, 'PaperPositionMode', 'auto'); set(gca, 'FontSize', 24); saveas(gcf, ['figures/' imname '_noise_coeffs.eps'], 'epsc');

% Discrete Wavelet Transform (Hard Threshold)
X_DFT = ThreshWave2(Xn, 'H', 0);
DFT_snr = psnr(X_DFT, X)
figure; imshow(X_DFT, []); set(gcf, 'PaperPositionMode', 'auto'); set(gca, 'FontSize', 24); saveas(gcf, ['figures/' imname '_DFT_denoised.eps'], 'epsc');

% Spin-Cycle translation invariant Wavelet Transform (Hard Threshold)
X_cycle = ThreshWave2(Xn, 'H', 1);
cycle_snr = psnr(X_cycle, X)
figure; imshow(X_cycle, []); set(gcf, 'PaperPositionMode', 'auto'); set(gca, 'FontSize', 24); saveas(gcf, ['figures/' imname '_cycle_denoised.eps'], 'epsc');



function snr = psnr(A, ref)

maxI = max(ref(:));
MSE = mean((A(:) - ref(:)).^2);
snr = 20*log10(maxI) - 10*log10(MSE+eps);
